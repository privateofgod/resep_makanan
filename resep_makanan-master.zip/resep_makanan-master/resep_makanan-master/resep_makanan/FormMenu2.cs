﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace resep_makanan
{
    public partial class FormMenu2 : Form
    {
        public FormMenu2()
        {
            InitializeComponent();
        }

        private void FormMenu2_Load(object sender, EventArgs e)
        {

        }
    }
}
